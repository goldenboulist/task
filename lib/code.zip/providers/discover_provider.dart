import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import '../models/song.dart';
import '../models/discover_song.dart';
import '../providers/music_provider.dart';
import '../services/discover_service.dart';

enum DiscoverStatus { idle, loading, loaded, error }

class DiscoverProvider extends ChangeNotifier {
  // Dedicated player for 30-sec Deezer previews — never touches
  // the main MusicAudioHandler so playback isn't interrupted.
  final _previewPlayer = AudioPlayer();

  // ── State ──────────────────────────────────────────────────────
  DiscoverStatus _status = DiscoverStatus.idle;
  List<String> _seedArtists   = [];
  List<String> _similarArtists = [];
  List<DiscoverSong> _suggestions = [];
  String? _playingId;
  bool   _isPreviewPlaying = false;
  String? _error;

  final Set<String> _downloading = {};
  final Set<String> _addedIds    = {};

  // ── Getters ────────────────────────────────────────────────────
  DiscoverStatus    get status          => _status;
  List<String>      get seedArtists     => _seedArtists;
  List<String>      get similarArtists  => _similarArtists;
  List<DiscoverSong> get suggestions    => _suggestions;
  String?           get playingId       => _playingId;
  bool              get isPreviewPlaying => _isPreviewPlaying;
  String?           get error           => _error;
  bool isDownloading(String id) => _downloading.contains(id);
  bool isAdded(String id)       => _addedIds.contains(id);

  DiscoverProvider() {
    _previewPlayer.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _isPreviewPlaying = false;
        notifyListeners();
      }
    });
  }

  // ── Discover ───────────────────────────────────────────────────

  Future<void> discover(List<Song> localSongs) async {
    if (_status == DiscoverStatus.loading) return;

    await _stopPreview();
    _status       = DiscoverStatus.loading;
    _seedArtists  = [];
    _similarArtists = [];
    _suggestions  = [];
    _error        = null;
    _addedIds.clear();
    notifyListeners();

    try {
      final result = await DiscoverService.instance.discover(localSongs);
      _seedArtists    = result.seedArtists;
      _similarArtists = result.similarArtists;
      _suggestions    = result.songs;
      _status         = DiscoverStatus.loaded;
    } catch (e) {
      _error  = e.toString();
      _status = DiscoverStatus.error;
      debugPrint('[DiscoverProvider] $e');
    }
    notifyListeners();
  }

  // ── Preview playback ───────────────────────────────────────────

  Future<void> togglePreview(DiscoverSong song) async {
    if (song.previewUrl == null) return;

    if (_playingId == song.id) {
      if (_isPreviewPlaying) {
        await _previewPlayer.pause();
        _isPreviewPlaying = false;
      } else {
        await _previewPlayer.play();
        _isPreviewPlaying = true;
      }
      notifyListeners();
      return;
    }

    _playingId        = song.id;
    _isPreviewPlaying = true;
    notifyListeners();

    try {
      await _previewPlayer.setUrl(song.previewUrl!);
      await _previewPlayer.play();
    } catch (e) {
      _isPreviewPlaying = false;
      debugPrint('[DiscoverProvider] Preview error: $e');
      notifyListeners();
    }
  }

  Future<void> stopPreview() async {
    await _stopPreview();
    notifyListeners();
  }

  Future<void> _stopPreview() async {
    await _previewPlayer.stop();
    _playingId        = null;
    _isPreviewPlaying = false;
  }

  // ── Add to library ────────────────────────────────────────────

  /// Downloads the 30 s Deezer preview and saves it as a local Song.
  Future<void> addToLibrary(
      DiscoverSong discoverSong, MusicProvider musicProvider) async {
    if (_addedIds.contains(discoverSong.id)) return;
    if (discoverSong.previewUrl == null) {
      throw Exception('Pas de preview disponible pour cette chanson.');
    }

    _downloading.add(discoverSong.id);
    notifyListeners();

    try {
      final response = await http
          .get(Uri.parse(discoverSong.previewUrl!))
          .timeout(const Duration(seconds: 30));

      if (response.statusCode != 200) {
        throw Exception('Téléchargement échoué (HTTP ${response.statusCode}).');
      }

      final base    = await getApplicationDocumentsDirectory();
      final dir     = Directory(p.join(base.path, 'music'));
      if (!await dir.exists()) await dir.create(recursive: true);

      final songId  = _newId();
      final destPath = p.join(dir.path, '$songId.mp3');
      await File(destPath).writeAsBytes(response.bodyBytes);

      final song = Song(
        id:        songId,
        title:     discoverSong.title,
        artist:    discoverSong.artist,
        localPath: destPath,
        synced:    false,
        createdAt: DateTime.now().toUtc(),
        updatedAt: DateTime.now().toUtc(),
      );

      await musicProvider.addDiscoveredSong(song);
      _addedIds.add(discoverSong.id);
    } finally {
      _downloading.remove(discoverSong.id);
      notifyListeners();
    }
  }

  // ── Helpers ───────────────────────────────────────────────────

  String _newId() {
    const hex = '0123456789abcdef';
    final buf  = StringBuffer();
    final rand = DateTime.now().microsecondsSinceEpoch;
    for (var i = 0; i < 32; i++) {
      if (i == 8 || i == 12 || i == 16 || i == 20) buf.write('-');
      buf.write(hex[(rand >> (i * 2)) & 0xF]);
    }
    return buf.toString();
  }

  @override
  void dispose() {
    _previewPlayer.dispose();
    super.dispose();
  }
}